﻿#include <iostream>
#include <ctime>
#include <cstdlib>
#include <list>
#include <string>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>

void setPicture(SDL_Surface *outs, Uint32 x, Uint32 y, SDL_Surface *ins)
{
    SDL_Rect myPos;
    myPos.x = x;
    myPos.y = y;
    myPos.w = ins->w;
    myPos.h = ins->h;
    SDL_BlitSurface(ins, NULL, outs, &myPos);
}

int main(int argc, char *argv[])
{
    SDL_Window* window = NULL;
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER) != 0)
    {
        return 1;
    }
    if (IMG_Init(IMG_INIT_PNG) != IMG_INIT_PNG)
    {
        SDL_Quit();
        return 1;
    }
    if (TTF_Init() != 0)
    {
        IMG_Quit();
        SDL_Quit();
        return 1;
    }
    window = SDL_CreateWindow("Samurai", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 1365, 767, 0);
    if (window == NULL)
    {
        TTF_Quit();
        IMG_Quit();
        SDL_Quit();
        return 1;
    }
    SDL_Surface* background = IMG_Load("background.png");
    if (background == NULL)
    {
        SDL_DestroyWindow(window);
        TTF_Quit();
        IMG_Quit();
        SDL_Quit();
        return 1;
    }
    SDL_Surface* playerleft = IMG_Load("playerleft.png");
    if (playerleft == NULL)
    {
        SDL_FreeSurface(background);
        SDL_DestroyWindow(window);
        TTF_Quit();
        IMG_Quit();
        SDL_Quit();
        return 1;
    }
    SDL_Surface* playerright = IMG_Load("playerright.png");
    if (playerleft == NULL)
    {
        SDL_FreeSurface(background);
        SDL_FreeSurface(playerleft);
        SDL_DestroyWindow(window);
        TTF_Quit();
        IMG_Quit();
        SDL_Quit();
        return 1;
    }
    SDL_Surface* weapon = IMG_Load("weapon.png");
    if (weapon == NULL)
    {
        SDL_FreeSurface(background);
        SDL_FreeSurface(playerleft);
        SDL_FreeSurface(playerright);
        SDL_DestroyWindow(window);
        TTF_Quit();
        IMG_Quit();
        SDL_Quit();
        return 1;
    }
    SDL_Surface* enemy = IMG_Load("enemy.png");
    if (enemy == NULL)
    {
        SDL_FreeSurface(background);
        SDL_FreeSurface(playerleft);
        SDL_FreeSurface(playerright);
        SDL_FreeSurface(weapon);
        SDL_DestroyWindow(window);
        TTF_Quit();
        IMG_Quit();
        SDL_Quit();
        return 1;
    }
    TTF_Font* ingamelabel = TTF_OpenFont("Oswald-VariableFont_wght.ttf", 30);
    if (ingamelabel == NULL)
    {
        SDL_FreeSurface(background);
        SDL_FreeSurface(playerleft);
        SDL_FreeSurface(playerright);
        SDL_FreeSurface(weapon);
        SDL_FreeSurface(enemy);
        SDL_DestroyWindow(window);
        TTF_Quit();
        IMG_Quit();
        SDL_Quit();
        return 1;
    }
    TTF_Font* label = TTF_OpenFont("Oswald-VariableFont_wght.ttf", 60);
    if (label == NULL)
    {
        SDL_FreeSurface(background);
        SDL_FreeSurface(playerleft);
        SDL_FreeSurface(playerright);
        SDL_FreeSurface(weapon);
        SDL_FreeSurface(enemy);
        TTF_CloseFont(ingamelabel);
        SDL_DestroyWindow(window);
        TTF_Quit();
        IMG_Quit();
        SDL_Quit();
        return 1;
    }
    bool exit = false;
    bool left = false;
    bool is_jump = false;
    int jump = 11;
    int jump_count = jump;
    Uint32 player_x = 60;
    Uint32 player_y = 650;
    Uint32 player_speed = 6;
    std::srand(std::time(nullptr));
    struct enemy_point
    {
        int x;
        int y;
        enemy_point()
        {
            Uint32 y_select[] = { 400, 650 };
            x = 1300;
            y = y_select[rand()%2];
        }
        bool test_object(int o_x, int o_y, int o_w, int o_h, int w, int h)
        {
            bool ans = false;
            if ((o_x <= x + w) && (o_x >= x))
            {
                if ((o_y <= y + h) && (o_y >= y))
                {
                    ans = true;
                }
                else if ((o_y + o_h <= y + h) && (o_y + o_h >= y))
                {
                    ans = true;
                }
            }
            else if ((o_x + o_w <= x + w) && (o_x + o_w >= x))
            {
                if ((o_y <= y + h) && (o_y >= y))
                {
                    ans = true;
                }
                else if ((o_y + o_h <= y + h) && (o_y + o_h >= y))
                {
                    ans = true;
                }
            }
            return ans;
        }
    };
    std::list<enemy_point> enemy_list;
    enemy_list.clear();
    Uint32 enemy_timer = SDL_GetTicks();
    Uint32 enemy_speed = 5;
    double UserScore = 0;
    struct shuriken_point
    {
        int x;
        int y;
        shuriken_point(int s_x, int s_y)
        {
            x = s_x;
            y = s_y;
        }
    };
    std::list<shuriken_point> shuriken_list;
    shuriken_list.clear();
    Uint32 shuriken_left = 10;
    Uint32 shuriken_speed = 8;
    Uint32 shuriken_time = 0;
    SDL_Event e;
    Uint32 time = SDL_GetTicks();
    double highscore = 0;
    bool endgame = false;
    while (!exit)
    {
        SDL_BlitSurface(background, NULL, SDL_GetWindowSurface(window), NULL);
        if (!enemy_list.empty())
        {
            for (auto i = enemy_list.begin(); i != enemy_list.end(); ++i)
            {
                setPicture(SDL_GetWindowSurface(window), i->x, i->y, enemy);
            }
        }
        if (!shuriken_list.empty())
        {
            for (auto i = shuriken_list.begin(); i != shuriken_list.end(); ++i)
            {
                setPicture(SDL_GetWindowSurface(window), i->x, i->y, weapon);
            }
        }
        if (left)
        {
            setPicture(SDL_GetWindowSurface(window), player_x, player_y, playerleft);
        }
        else
        {
            setPicture(SDL_GetWindowSurface(window), player_x, player_y, playerright);
        }
        SDL_Color col;
        col.r = 0;
        col.g = 0;
        col.b = 0;
        col.a = 255;
        std::string str1 = "Shurikens left: " + std::to_string(shuriken_left);
        SDL_Surface* text1 = TTF_RenderUTF8_Blended(ingamelabel,str1.c_str(), col);
        setPicture(SDL_GetWindowSurface(window), 10, 10, text1);
        SDL_FreeSurface(text1);
        std::string str2 = "Your Score: " + std::to_string(UserScore);
        SDL_Surface* text2 = TTF_RenderUTF8_Blended(ingamelabel, str2.c_str(), col);
        setPicture(SDL_GetWindowSurface(window), 250, 10, text2);
        SDL_FreeSurface(text2);
        SDL_UpdateWindowSurface(window);
        if (SDL_GetTicks() - time > 15)
        {
            time = SDL_GetTicks();
            while (SDL_PollEvent(&e))
            {
                if (e.type == SDL_QUIT)
                {
                    exit = true;
                }
                else if (e.type == SDL_KEYUP)
                { 
                    if (e.key.keysym.scancode == SDL_SCANCODE_X)
                    {
                        shuriken_list.push_back(shuriken_point(player_x + playerleft->w, player_y));
                        --shuriken_left;
                        shuriken_time = SDL_GetTicks();
                    }
                }
            }
            const Uint8* keys = SDL_GetKeyboardState(NULL);
            if (keys[SDL_SCANCODE_RIGHT])
            {
                left = false;
                if (player_x < 1100)
                {
                    player_x += player_speed;
                }
            }
            if (keys[SDL_SCANCODE_LEFT])
            {
                left = true;
                if (player_x > 50)
                {
                    player_x -= player_speed;
                }
            }
            if (keys[SDL_SCANCODE_SPACE] && !is_jump)
            {
                is_jump = true;
            }
            if (is_jump)
            {
                if (jump_count >= -jump)
                {
                    if (jump_count > 0)
                    {
                        player_y -= (jump_count * jump_count) / 2;
                    }
                    else
                    {
                        player_y += (jump_count * jump_count) / 2;
                    }
                    jump_count--;
                }
                else
                {
                    jump_count = jump;
                    is_jump = false;
                }
            }
            if (!enemy_list.empty())
            {
                for (auto i = enemy_list.begin(); i != enemy_list.end();)
                {
                    i->x -= enemy_speed;
                    if (i->x < -40)
                    {
                        i = enemy_list.erase(i);
                        UserScore -= 0.5;
                    }
                    else
                    {
                        ++i;
                    }
                }
            }
            if (!shuriken_list.empty())
            {
                for (auto i = shuriken_list.begin(); i != shuriken_list.end();)
                {
                    i->x += shuriken_speed;
                    if (i->x > 1400)
                    {
                        i = shuriken_list.erase(i);
                    }
                    else
                    {
                        ++i;
                    }
                }
            }
            if (SDL_GetTicks() - enemy_timer > 2000)
            {
                enemy_list.push_back(enemy_point());
                enemy_timer = SDL_GetTicks();
            }
            /*if (keys[SDL_SCANCODE_X] && (shuriken_left>0) && (SDL_GetTicks() - shuriken_time>100))
            {
                shuriken_list.push_back(shuriken_point(player_x+playerleft->w,player_y));
                --shuriken_left;
                shuriken_time = SDL_GetTicks();
            }*/
            if (!enemy_list.empty())
            {
                for (auto i = enemy_list.begin(); i != enemy_list.end(); ++i)
                {
                    if (i->test_object(player_x, player_y, playerleft->w, playerleft->h, enemy->w, enemy->h))
                    {
                        endgame = 1;
                    }
                }
            }
            if (!enemy_list.empty() && !shuriken_list.empty() && !endgame)
            {
                for (auto i = shuriken_list.begin(); i != shuriken_list.end(); )
                {
                    bool st = false;
                    for (auto j = enemy_list.begin(); j != enemy_list.end();)
                    {
                        if (j->test_object(i->x, i->y, weapon->w, weapon->h, enemy->w, enemy->h))
                        {
                            i = shuriken_list.erase(i);
                            enemy_list.erase(j);
                            j = enemy_list.end();
                            UserScore += 1;
                            shuriken_left = 10;
                            st = true;
                        }
                        if (!st)
                        {
                            ++j;
                        }
                    }
                    if (!st)
                    {
                        ++i;
                    }
                }
            }
        }
        if (UserScore > highscore)
        {
            highscore = UserScore;
        }
        while (endgame)
        {
            SDL_FillRect(SDL_GetWindowSurface(window), NULL, SDL_MapRGB(SDL_GetWindowSurface(window)->format,20,20,20));
            std::string fs = "Score: " + std::to_string(UserScore);
            col.r = 250;
            col.g = 220;
            col.b = 40;
            SDL_Surface *finalscore = TTF_RenderUTF8_Blended(label, fs.c_str(), col);
            setPicture(SDL_GetWindowSurface(window), 5, 40, finalscore);
            SDL_FreeSurface(finalscore);
            fs = "Highest score: "+std::to_string(highscore);
            SDL_Surface* highestscore = TTF_RenderUTF8_Blended(label, fs.c_str(), col);
            setPicture(SDL_GetWindowSurface(window), 5, 140, highestscore);
            SDL_FreeSurface(highestscore);
            col.r = 255;
            col.g = 255;
            col.b = 255;
            SDL_Surface* you_lose = TTF_RenderUTF8_Blended(label, "You lose", col);
            setPicture(SDL_GetWindowSurface(window), 630, 40, you_lose);
            SDL_FreeSurface(you_lose);
            col.r = 50;
            col.g = 200;
            col.b = 215;
            SDL_Surface* try_again = TTF_RenderUTF8_Blended(label, "Try again", col);
            setPicture(SDL_GetWindowSurface(window), 630, 140, try_again);
            SDL_Surface* to_close = TTF_RenderUTF8_Blended(label, "Close", col);
            setPicture(SDL_GetWindowSurface(window), 630, 240, to_close);
            SDL_UpdateWindowSurface(window);
            while (SDL_PollEvent(&e))
            {
                if (e.type == SDL_QUIT)
                {
                    exit = true;
                    endgame = false;
                }
                else if (e.type == SDL_MOUSEBUTTONUP)
                {
                    if ((e.button.x >= 630) && (e.button.x < 630 + try_again->w) && (e.button.y >= 140) && (e.button.y < 140 + try_again->h))
                    {
                        UserScore = 0;
                        endgame = false;
                        shuriken_left = 10;
                        enemy_list.clear();
                        shuriken_list.clear();
                        shuriken_time = 0;
                        enemy_timer = SDL_GetTicks();
                        player_x = 60;
                        player_y = 650;
                        jump_count = jump;
                        is_jump = false;
                    }
                    if ((e.button.x >= 630) && (e.button.x < 630 + to_close->w) && (e.button.y >= 240) && (e.button.y < 240 + to_close->h))
                    {
                        endgame = false;
                        exit = true;
                    }
                }
            }
            SDL_FreeSurface(try_again);
            SDL_FreeSurface(to_close);
        }
    }
    SDL_FreeSurface(background);
    SDL_FreeSurface(playerleft);
    SDL_FreeSurface(playerright);
    SDL_FreeSurface(weapon);
    SDL_FreeSurface(enemy);
    TTF_CloseFont(ingamelabel);
    TTF_CloseFont(label);
    SDL_DestroyWindow(window);
    TTF_Quit();
    IMG_Quit();
    SDL_Quit();
    return 0;
}
